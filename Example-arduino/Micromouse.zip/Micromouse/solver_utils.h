#ifndef SOLVER_UTILS_H
#define SOLVER_UTILS_H

#include "position.h"
#include "solver.h"

Pose2 stateToPose(State s);

#include "solver_utils.hpp"

#endif